from django.contrib import admin
from .models import Categoria, Planta, Cliente


admin.site.register(Categoria)
admin.site.register(Planta)
admin.site.register(Cliente)